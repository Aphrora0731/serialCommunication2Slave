//
// Created by Administrator on 2023/12/22.
//

#ifndef _GENERATEALGORITHM_H_
#define _GENERATEALGORITHM_H_
#include <cstdint>
#include <vector>
std::vector<uint16_t> linear_generate(uint16_t first_item,uint16_t last_item,size_t num);
#endif //_GENERATEALGORITHM_H_
